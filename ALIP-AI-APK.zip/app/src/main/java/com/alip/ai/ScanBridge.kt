package com.alip.ai

import android.graphics.Bitmap

object ScanBridge {
    /** (base64 jpeg, thumbnail) ; null jika dibatalkan */
    var callback: ((String?, Bitmap?) -> Unit)? = null
}
