package com.alip.ai

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("alip", Context.MODE_PRIVATE)
    fun accent(c: Context): Int = sp(c).getInt("accent", 0xFF30D158.toInt())
    fun setAccent(c: Context, v: Int) = sp(c).edit().putInt("accent", v).apply()
    fun opacity(c: Context): Int = sp(c).getInt("opacity", 80)
    fun setOpacity(c: Context, v: Int) = sp(c).edit().putInt("opacity", v).apply()
}
