package com.alip.ai

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ClipDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {
    private val MP = ViewGroup.LayoutParams.MATCH_PARENT
    private val WC = ViewGroup.LayoutParams.WRAP_CONTENT
    private val green = 0xFF30D158.toInt()
    private lateinit var root: FrameLayout
    private var stage: View? = null
    private var pendingLaunch = false
    private var progressAnim: ValueAnimator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF04110A.toInt(), 0xFF0B3D22.toInt(), 0xFF052313.toInt())
            )
        }
        blob(300, green, Gravity.TOP or Gravity.START, 70f)
        blob(260, 0xFF0A84FF.toInt(), Gravity.BOTTOM or Gravity.END, -60f)
        blob(200, 0xFFBF5AF2.toInt(), Gravity.CENTER, 40f)
        setContentView(root)
        swap(splash())
    }

    override fun onResume() {
        super.onResume()
        if (pendingLaunch && Settings.canDrawOverlays(this)) {
            pendingLaunch = false
            launchFloating()
        }
    }

    override fun onDestroy() {
        progressAnim?.cancel()
        super.onDestroy()
    }

    private fun blob(sizeDp: Int, color: Int, gravity: Int, dx: Float) {
        val v = View(this)
        v.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            gradientType = GradientDrawable.RADIAL_GRADIENT
            gradientRadius = dp(sizeDp / 2)
            colors = intArrayOf(Glass.withAlpha(color, 0x77), Glass.withAlpha(color, 0))
        }
        root.addView(v, FrameLayout.LayoutParams(dpi(sizeDp), dpi(sizeDp), gravity))
        ObjectAnimator.ofFloat(v, "translationX", 0f, dpi(dx.toInt()).toFloat()).apply {
            duration = 7000
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            start()
        }
    }

    /** Transisi mulus antar layar */
    private fun swap(next: View) {
        val old = stage
        fun add() {
            root.addView(next, FrameLayout.LayoutParams(MP, MP))
            next.alpha = 0f
            next.scaleX = 0.96f
            next.scaleY = 0.96f
            next.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(650)
                .setInterpolator(DecelerateInterpolator()).start()
            stage = next
        }
        if (old == null) add() else
            old.animate().alpha(0f).scaleX(1.05f).scaleY(1.05f).setDuration(450)
                .withEndAction { root.removeView(old); add() }.start()
    }

    private fun stageOf(inner: View): FrameLayout = FrameLayout(this).apply {
        addView(inner, FrameLayout.LayoutParams(MP, WC, Gravity.CENTER).apply { setMargins(dpi(26), 0, dpi(26), 0) })
        addView(
            Glass.text(this@MainActivity, Config.FOOTER, 12f, 0xA0FFFFFF.toInt()),
            FrameLayout.LayoutParams(WC, WC, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dpi(18) }
        )
    }

    private fun column() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
    }

    private fun logoView(sizeDp: Int): ImageView = ImageView(this).apply {
        setImageResource(R.drawable.logo)
        setPadding(dpi(sizeDp / 10), dpi(sizeDp / 10), dpi(sizeDp / 10), dpi(sizeDp / 10))
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.WHITE)
            setStroke(dpi(3), 0x88FFFFFF.toInt())
        }
        Glass.circle(this)
    }

    // ---------- 1. Splash + loading 1..100% (13 detik) ----------
    private fun splash(): View {
        val col = column()
        val logo = logoView(150)
        col.addView(logo, LinearLayout.LayoutParams(dpi(150), dpi(150)))
        ObjectAnimator.ofPropertyValuesHolder(
            logo, PropertyValuesHolder.ofFloat("scaleX", 1f, 1.07f), PropertyValuesHolder.ofFloat("scaleY", 1f, 1.07f)
        ).apply { duration = 900; repeatMode = ValueAnimator.REVERSE; repeatCount = ValueAnimator.INFINITE; start() }

        col.addView(
            Glass.text(this, "ALIP AI - MTS", 27f, Color.WHITE, true),
            LinearLayout.LayoutParams(WC, WC).apply { topMargin = dpi(24) }
        )
        col.addView(Glass.text(this, "@AI Entertainment", 15f, 0xB3FFFFFF.toInt()))

        val track = GradientDrawable().apply {
            cornerRadius = dp(10); setColor(0x33FFFFFF); setStroke(dpi(1), 0x55FFFFFF)
        }
        val fill = ClipDrawable(
            GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(green, 0xFF8EF5A8.toInt()))
                .apply { cornerRadius = dp(10) },
            Gravity.START, ClipDrawable.HORIZONTAL
        )
        val layers = LayerDrawable(arrayOf<Drawable>(track, fill)).apply {
            setId(0, android.R.id.background)
            setId(1, android.R.id.progress)
        }
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progress = 1; isIndeterminate = false; progressDrawable = layers
        }
        col.addView(bar, LinearLayout.LayoutParams(MP, dpi(14)).apply { topMargin = dpi(36) })
        val pct = Glass.text(this, "1%", 14f, Color.WHITE, true)
        col.addView(pct, LinearLayout.LayoutParams(WC, WC).apply { topMargin = dpi(10) })

        progressAnim = ValueAnimator.ofInt(1, 100).apply {
            duration = 13000
            interpolator = LinearInterpolator()
            addUpdateListener { val v = it.animatedValue as Int; bar.progress = v; pct.text = "$v%" }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) { swap(login()) }
            })
            start()
        }
        return stageOf(col)
    }

    // ---------- 2. Login ----------
    private fun login(): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dpi(22), dpi(26), dpi(22), dpi(24))
            background = Glass.bg(this@MainActivity, 30f)
        }
        card.addView(logoView(76), LinearLayout.LayoutParams(dpi(76), dpi(76)))
        card.addView(Glass.text(this, "Login", 24f, Color.WHITE, true), LinearLayout.LayoutParams(WC, WC).apply { topMargin = dpi(12) })
        card.addView(Glass.text(this, "Masukkan password untuk membuka ALIP AI", 13f, 0xB3FFFFFF.toInt()).apply { gravity = Gravity.CENTER })

        val et = EditText(this).apply {
            hint = "Password"
            setHintTextColor(0x80FFFFFF.toInt())
            setTextColor(Color.WHITE)
            textSize = 16f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            imeOptions = EditorInfo.IME_ACTION_DONE
            setSingleLine(true)
            gravity = Gravity.CENTER
            background = Glass.bg(this@MainActivity, 22f)
            setPadding(dpi(16), dpi(13), dpi(16), dpi(13))
        }
        card.addView(et, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dpi(18) })
        val err = Glass.text(this, "", 12f, 0xFFFF6B6B.toInt())
        card.addView(err, LinearLayout.LayoutParams(WC, WC).apply { topMargin = dpi(8) })
        val btn = Glass.button(this, "Login", green, 16f)
        card.addView(btn, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dpi(14) })

        fun doLogin() {
            if (et.text.toString() == Config.PASSWORD) {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(et.windowToken, 0)
                swap(welcome())
            } else {
                err.text = "Password salah, coba lagi"
                ObjectAnimator.ofFloat(card, "translationX", 0f, -24f, 24f, -16f, 16f, -8f, 8f, 0f).setDuration(450).start()
            }
        }
        btn.setOnClickListener { doLogin() }
        et.setOnEditorActionListener { _, _, _ -> doLogin(); true }
        return stageOf(card)
    }

    // ---------- 3. Welcome (transisi mulus) + tombol Jalankan ----------
    private fun welcome(): View {
        val col = column()
        val t1 = Glass.text(this, "WELCOME TO ALIP AI", 28f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER; letterSpacing = 0.06f
        }
        val t2 = Glass.text(this, "Helping and providing answers when having difficulties while studying", 15f, 0xCCFFFFFF.toInt())
            .apply { gravity = Gravity.CENTER }
        val btn = Glass.button(this, "▶  Jalankan", green, 17f).apply {
            setPadding(dpi(44), dpi(14), dpi(44), dpi(14))
            setOnClickListener { launchFloating() }
        }
        col.addView(logoView(96), LinearLayout.LayoutParams(dpi(96), dpi(96)).apply { bottomMargin = dpi(26) })
        col.addView(t1)
        col.addView(t2, LinearLayout.LayoutParams(WC, WC).apply { topMargin = dpi(14) })
        col.addView(btn, LinearLayout.LayoutParams(WC, WC).apply { topMargin = dpi(44) })
        listOf<View>(t1, t2, btn).forEachIndexed { i, v ->
            v.alpha = 0f
            v.translationY = dpi(30).toFloat()
            v.animate().alpha(1f).translationY(0f).setStartDelay(500L + i * 700L).setDuration(800)
                .setInterpolator(DecelerateInterpolator()).start()
        }
        return stageOf(col)
    }

    // ---------- 4. Jalankan layar mengambang ----------
    private fun launchFloating() {
        if (!Settings.canDrawOverlays(this)) {
            pendingLaunch = true
            Toast.makeText(this, "Izinkan \"Tampil di atas aplikasi lain\" untuk ALIP AI", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
            return
        }
        startFloating()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 7) startFloating()
    }

    private fun startFloating() {
        startForegroundService(Intent(this, FloatingService::class.java))
        Toast.makeText(this, "ALIP AI berjalan di layar 🙌", Toast.LENGTH_SHORT).show()
        finish()
    }
}
