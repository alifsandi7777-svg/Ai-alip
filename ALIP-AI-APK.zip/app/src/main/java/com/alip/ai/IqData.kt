package com.alip.ai

data class IqQ(val q: String, val opts: List<String>, val ans: Int)

object IqData {
    val questions = listOf(
        IqQ("Lanjutkan deret: 2, 4, 8, 16, ...", listOf("24", "30", "32", "36"), 2),
        IqQ("Lanjutkan deret: 1, 1, 2, 3, 5, 8, ...", listOf("11", "12", "13", "15"), 2),
        IqQ("Lanjutkan deret: 100, 91, 82, 73, ...", listOf("62", "63", "64", "65"), 2),
        IqQ("Lanjutkan deret: 1, 4, 9, 16, ...", listOf("20", "24", "25", "36"), 2),
        IqQ("Kucing : Mengeong = Anjing : ...", listOf("Mengaum", "Menggonggong", "Berkokok", "Mencicit"), 1),
        IqQ("Dokter : Rumah Sakit = Guru : ...", listOf("Pasar", "Kantor", "Sekolah", "Bengkel"), 2),
        IqQ("Semua burung bertelur. Merpati adalah burung. Maka merpati ...", listOf("Menyusui", "Bertelur", "Tidak bisa terbang", "Mamalia"), 1),
        IqQ("Jika A > B dan B > C, maka ...", listOf("C > A", "A < C", "A > C", "B > A"), 2),
        IqQ("3 pekerja membuat 3 kursi dalam 3 hari. Berapa kursi dibuat 6 pekerja dalam 3 hari?", listOf("3", "6", "9", "12"), 1),
        IqQ("Mana yang tidak sejenis? Apel, Jeruk, Mangga, Wortel", listOf("Apel", "Jeruk", "Mangga", "Wortel"), 3)
    )

    fun label(iq: Int) = when {
        iq >= 130 -> "Sangat cerdas 🔥"
        iq >= 115 -> "Di atas rata-rata 👍"
        iq >= 100 -> "Rata-rata 🙂"
        iq >= 85 -> "Cukup baik, terus berlatih 💪"
        else -> "Tetap semangat belajar 📚"
    }
}
