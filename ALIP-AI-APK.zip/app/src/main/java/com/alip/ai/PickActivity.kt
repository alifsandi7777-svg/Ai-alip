package com.alip.ai

import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.concurrent.thread

class PickActivity : ComponentActivity() {
    private var camUri: Uri? = null

    private val takePic = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = camUri
        if (ok && u != null) process(u) else cancel()
    }
    private val pickImg = registerForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) process(u) else cancel()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AlertDialog.Builder(this)
            .setTitle("Scan Foto")
            .setItems(arrayOf("📷  Kamera", "🖼️  Galeri")) { _, which ->
                if (which == 0) openCam() else pickImg.launch("image/*")
            }
            .setOnCancelListener { cancel() }
            .show()
    }

    private fun openCam() {
        try {
            val dir = File(cacheDir, "images").apply { mkdirs() }
            val f = File(dir, "scan.jpg")
            val u = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            camUri = u
            takePic.launch(u)
        } catch (e: Exception) {
            cancel()
        }
    }

    private fun cancel() {
        ScanBridge.callback?.invoke(null, null)
        ScanBridge.callback = null
        finish()
    }

    private fun process(uri: Uri) {
        thread {
            try {
                val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                var s = 1
                while (opts.outWidth / s > 1600 || opts.outHeight / s > 1600) s *= 2
                val o2 = BitmapFactory.Options().apply { inSampleSize = s }
                var bmp = contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, o2) }!!
                val orient = contentResolver.openInputStream(uri)?.use {
                    ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)
                } ?: 1
                val deg = when (orient) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
                if (deg != 0f) {
                    val m = Matrix().apply { postRotate(deg) }
                    bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                }
                val bos = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.JPEG, 82, bos)
                val b64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
                val k = 320f / maxOf(bmp.width, bmp.height)
                val thumb = Bitmap.createScaledBitmap(
                    bmp, (bmp.width * k).toInt().coerceAtLeast(1), (bmp.height * k).toInt().coerceAtLeast(1), true
                )
                ScanBridge.callback?.invoke(b64, thumb)
            } catch (e: Exception) {
                ScanBridge.callback?.invoke(null, null)
            }
            ScanBridge.callback = null
            runOnUiThread { finish() }
        }
    }
}
