package com.alip.ai

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ColorStateList
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as WLP
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import kotlin.concurrent.thread
import kotlin.math.abs

class FloatingService : Service() {
    private val MP = ViewGroup.LayoutParams.MATCH_PARENT
    private val WC = ViewGroup.LayoutParams.WRAP_CONTENT
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager

    private var panel: LinearLayout? = null
    private var bubble: ImageView? = null
    private lateinit var panelLp: WLP
    private lateinit var bubbleLp: WLP
    private var panelShown = false
    private var bubbleShown = false

    private lateinit var content: FrameLayout
    private lateinit var tabViews: List<TextView>
    private var curTab = 0

    private var chatPage: LinearLayout? = null
    private var chatBox: LinearLayout? = null
    private var chatScroll: ScrollView? = null
    private var robot: RobotView? = null
    private var input: EditText? = null
    private var sendBtn: TextView? = null
    private var modeChip: TextView? = null
    private var robotSmall = false
    private var busy = false
    private var mode = "umum"
    private val history = JSONArray()

    private val accent: Int get() = Prefs.accent(this)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        startFg()
        if (panel == null) {
            if (!Settings.canDrawOverlays(this)) {
                stopSelf()
                return START_NOT_STICKY
            }
            build()
        }
        if (intent?.action == "SHOW") restore()
        return START_STICKY
    }

    override fun onDestroy() {
        try { if (panelShown) wm.removeView(panel) } catch (_: Exception) {}
        try { if (bubbleShown) wm.removeView(bubble) } catch (_: Exception) {}
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("alip", "ALIP AI", NotificationManager.IMPORTANCE_LOW))
        val fl = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val show = PendingIntent.getService(this, 1, Intent(this, FloatingService::class.java).setAction("SHOW"), fl)
        val stop = PendingIntent.getService(this, 2, Intent(this, FloatingService::class.java).setAction("STOP"), fl)
        val n = Notification.Builder(this, "alip")
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle("ALIP AI aktif")
            .setContentText("Ketuk untuk membuka layar ALIP AI")
            .setContentIntent(show)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "Tutup", stop).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    // ================= helpers =================
    private fun tv(t: String, sp: Float, color: Int = Color.WHITE, bold: Boolean = false) =
        Glass.text(this, t, sp, color, bold)

    private fun lp(w: Int, h: Int, wt: Float = 0f, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0) =
        LinearLayout.LayoutParams(w, h, wt).apply { setMargins(l, t, r, b) }

    private fun imm() = getSystemService(InputMethodManager::class.java)

    private fun iconBtn(label: String, onClick: () -> Unit): TextView =
        tv(label, 15f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = Glass.bg(this@FloatingService, 40f)
            isClickable = true
            setOnClickListener { onClick() }
            Glass.pressFx(this)
        }

    private fun setFocusable(on: Boolean) {
        if (!panelShown) return
        panelLp.flags = if (on) panelLp.flags and WLP.FLAG_NOT_FOCUSABLE.inv()
        else panelLp.flags or WLP.FLAG_NOT_FOCUSABLE
        wm.updateViewLayout(panel, panelLp)
    }

    private fun hideIme() {
        panel?.let { imm().hideSoftInputFromWindow(it.windowToken, 0) }
        setFocusable(false)
    }

    private fun field(hintText: String, number: Boolean): EditText = EditText(this).apply {
        hint = hintText
        setHintTextColor(0x80FFFFFF.toInt())
        setTextColor(Color.WHITE)
        textSize = 14f
        background = Glass.bg(this@FloatingService, 20f)
        setPadding(dpi(14), dpi(9), dpi(14), dpi(9))
        if (number) {
            inputType = InputType.TYPE_CLASS_NUMBER
            filters = arrayOf(android.text.InputFilter.LengthFilter(9))
        } else {
            maxLines = 4
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_UP) {
                setFocusable(true)
                ui.postDelayed({ v.requestFocus(); imm().showSoftInput(v, InputMethodManager.SHOW_IMPLICIT) }, 150)
            }
            false
        }
    }

    // ================= window =================
    private fun build() {
        val dm = resources.displayMetrics
        val pw = minOf(dm.widthPixels - dpi(20), dpi(380))
        val ph = minOf((dm.heightPixels * 0.78f).toInt(), dpi(640))
        val type = if (Build.VERSION.SDK_INT >= 26) WLP.TYPE_APPLICATION_OVERLAY else WLP.TYPE_PHONE
        panelLp = WLP(pw, ph, type, WLP.FLAG_NOT_FOCUSABLE or WLP.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (dm.widthPixels - pw) / 2
            y = dpi(60)
            softInputMode = WLP.SOFT_INPUT_ADJUST_PAN
            if (Build.VERSION.SDK_INT >= 31) {
                flags = flags or WLP.FLAG_BLUR_BEHIND
                blurBehindRadius = 30
            }
        }
        bubbleLp = WLP(dpi(58), dpi(58), type, WLP.FLAG_NOT_FOCUSABLE or WLP.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dpi(8)
            y = dpi(200)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpi(12), dpi(10), dpi(12), dpi(6))
        }
        panel = root
        styleRoot()
        root.addView(buildHeader())
        root.addView(buildTabs(), lp(MP, WC, 0f, 0, dpi(8), 0, dpi(6)))
        content = FrameLayout(this)
        root.addView(content, lp(MP, 0, 1f))
        root.addView(
            tv(Config.FOOTER, 11f, 0x99FFFFFF.toInt()).apply { gravity = Gravity.CENTER },
            lp(MP, WC, 0f, 0, dpi(4), 0, 0)
        )

        bubble = ImageView(this).apply {
            setImageResource(R.drawable.logo)
            scaleType = ImageView.ScaleType.CENTER_CROP
            Glass.circle(this)
            elevation = dp(6)
            var dX = 0f; var dY = 0f; var sx = 0; var sy = 0; var moved = false
            setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { dX = e.rawX; dY = e.rawY; sx = bubbleLp.x; sy = bubbleLp.y; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val ddx = e.rawX - dX
                        val ddy = e.rawY - dY
                        if (abs(ddx) > 10 || abs(ddy) > 10) moved = true
                        if (moved) {
                            bubbleLp.x = sx + ddx.toInt()
                            bubbleLp.y = sy + ddy.toInt()
                            wm.updateViewLayout(v, bubbleLp)
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) restore()
                }
                true
            }
        }

        wm.addView(root, panelLp)
        panelShown = true
        chatPage = buildChat()
        show(chatPage!!)
    }

    private fun minimize() {
        if (!panelShown) return
        hideIme()
        wm.removeView(panel)
        panelShown = false
        if (!bubbleShown) {
            wm.addView(bubble, bubbleLp)
            bubbleShown = true
        }
    }

    private fun restore() {
        if (bubbleShown) {
            wm.removeView(bubble)
            bubbleShown = false
        }
        if (!panelShown) {
            panelLp.flags = panelLp.flags or WLP.FLAG_NOT_FOCUSABLE
            wm.addView(panel, panelLp)
            panelShown = true
        }
    }

    private fun styleRoot() {
        val a = Prefs.opacity(this) * 255 / 100
        panel?.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.argb(a, 28, 38, 52), Color.argb((a * 0.8f).toInt(), 10, 18, 28))
        ).apply {
            cornerRadius = dp(28)
            setStroke(dpi(1), 0x66FFFFFF)
        }
    }

    private fun buildHeader(): View {
        val h = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.logo)
            scaleType = ImageView.ScaleType.CENTER_CROP
            Glass.circle(this)
        }
        h.addView(logo, lp(dpi(34), dpi(34)))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dpi(8), 0, 0, 0) }
        col.addView(tv("ALIP AI - MTS", 15f, Color.WHITE, true))
        col.addView(tv("@AI Entertainment", 10f, 0xB3FFFFFF.toInt()))
        h.addView(col, lp(0, WC, 1f))
        h.addView(iconBtn("—") { minimize() }, lp(dpi(34), dpi(34), 0f, 0, 0, dpi(6), 0))
        h.addView(iconBtn("✕") { stopSelf() }, lp(dpi(34), dpi(34)))
        var dX = 0f; var dY = 0f; var sx = 0; var sy = 0
        h.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dX = e.rawX; dY = e.rawY; sx = panelLp.x; sy = panelLp.y }
                MotionEvent.ACTION_MOVE -> {
                    panelLp.x = sx + (e.rawX - dX).toInt()
                    panelLp.y = sy + (e.rawY - dY).toInt()
                    wm.updateViewLayout(panel, panelLp)
                }
            }
            true
        }
        return h
    }

    private fun buildTabs(): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val names = listOf("💬 Chat", "☰ Menu", "📷 Scan", "⚙ Setting")
        tabViews = names.mapIndexed { i, n ->
            tv(n, 11f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                setPadding(dpi(2), dpi(8), dpi(2), dpi(8))
                isClickable = true
                setOnClickListener { onTab(i) }
                Glass.pressFx(this)
            }
        }
        tabViews.forEach { row.addView(it, lp(0, WC, 1f, dpi(2), 0, dpi(2), 0)) }
        refreshTabs()
        return row
    }

    private fun refreshTabs() {
        tabViews.forEachIndexed { i, t ->
            t.background = if (i == curTab) Glass.accentBg(this, accent, 16f) else Glass.bg(this, 16f)
        }
    }

    private fun onTab(i: Int) {
        when (i) {
            0 -> { curTab = 0; show(chatPage!!) }
            1 -> { curTab = 1; show(menuPage()) }
            2 -> { scan(); return }
            3 -> { curTab = 3; show(settingsPage()) }
        }
        refreshTabs()
    }

    private fun show(v: View) {
        hideIme()
        content.removeAllViews()
        content.addView(v, FrameLayout.LayoutParams(MP, MP))
    }

    // ================= chat =================
    private fun buildChat(): LinearLayout {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        robot = RobotView(this).apply { accent = this@FloatingService.accent }
        col.addView(robot, lp(MP, dpi(104)))
        modeChip = tv("Mode: Tanya Bebas", 11f).apply {
            gravity = Gravity.CENTER
            setPadding(dpi(10), dpi(4), dpi(10), dpi(4))
            background = Glass.bg(this@FloatingService, 12f)
        }
        col.addView(modeChip, lp(WC, WC, 0f, 0, 0, 0, dpi(4)).apply { gravity = Gravity.CENTER_HORIZONTAL })

        chatBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dpi(2), dpi(2), dpi(2), dpi(2)) }
        chatScroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(chatBox) }
        col.addView(chatScroll, lp(MP, 0, 1f))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(iconBtn("📷") { scan() }, lp(dpi(40), dpi(40)))
        input = field("Tanya sesuatu…", false)
        row.addView(input, lp(0, WC, 1f, dpi(6), 0, dpi(6), 0))
        sendBtn = iconBtn("➤") { send() }.apply { background = Glass.accentBg(this@FloatingService, accent, 40f) }
        row.addView(sendBtn, lp(dpi(40), dpi(40)))
        col.addView(row, lp(MP, WC, 0f, 0, dpi(6), 0, 0))

        addMsg("Halo! Aku ALIP AI 👋\nTanyakan apa saja soal pelajaranmu, atau scan foto soalnya.", false)
        return col
    }

    private fun addMsg(text: String, user: Boolean): TextView {
        val b = tv(text, 13.5f).apply {
            setPadding(dpi(12), dpi(8), dpi(12), dpi(8))
            background = if (user) Glass.accentBg(this@FloatingService, accent, 16f) else Glass.bg(this@FloatingService, 16f)
        }
        chatBox!!.addView(
            b,
            lp(WC, WC, 0f, if (user) dpi(40) else 0, dpi(3), if (user) 0 else dpi(40), dpi(3)).apply {
                gravity = if (user) Gravity.END else Gravity.START
            }
        )
        scrollDown()
        return b
    }

    private fun scrollDown() {
        chatScroll?.post { chatScroll?.smoothScrollTo(0, chatBox?.height ?: 0) }
    }

    private fun shrinkRobot() {
        if (robotSmall) return
        robotSmall = true
        val r = robot ?: return
        ValueAnimator.ofInt(dpi(104), dpi(64)).apply {
            duration = 350
            addUpdateListener {
                val lpm = r.layoutParams
                lpm.height = it.animatedValue as Int
                r.layoutParams = lpm
            }
            start()
        }
    }

    private fun sysPrompt(): String = when (mode) {
        "coding" -> "Kamu adalah ALIP AI mode Tanyakan Coding (Beta). Bantu menjawab pertanyaan pemrograman dan debugging untuk pelajar. Jawab dalam bahasa Indonesia, beri kode ringkas dalam blok kode dan penjelasan singkat yang mudah dipahami."
        "belajar" -> "Kamu adalah ALIP AI mode Belajar Coding (Beta): guru coding yang sabar untuk pemula (siswa MTs). Ajarkan bertahap, gunakan bahasa Indonesia sederhana, beri contoh kecil, dan akhiri dengan 1 latihan singkat. Jika levelnya belum jelas, tanyakan dulu."
        else -> "Kamu adalah ALIP AI, asisten belajar untuk siswa MTs dan sekolah. Jawab dalam bahasa Indonesia yang sederhana, ramah, dan jelas. Untuk soal hitungan berikan langkah-langkahnya. Jika tidak yakin, katakan dengan jujur."
    }

    private fun withSystem(): JSONArray {
        val a = JSONArray().put(JSONObject().put("role", "system").put("content", sysPrompt()))
        for (i in 0 until history.length()) a.put(history.get(i))
        return a
    }

    private fun send() {
        val et = input ?: return
        val q = et.text.toString().trim()
        if (q.isEmpty() || busy) return
        et.setText("")
        hideIme()
        shrinkRobot()
        addMsg(q, true)
        history.put(JSONObject().put("role", "user").put("content", q))
        while (history.length() > 12) history.remove(0)
        val wait = addMsg("⏳ Sedang berpikir…", false)
        busy = true
        val msgs = withSystem()
        thread {
            val res = try { Result.success(GroqClient.chat(msgs, Config.TEXT_MODELS)) } catch (e: Exception) { Result.failure(e) }
            ui.post {
                busy = false
                res.onSuccess {
                    wait.text = it
                    history.put(JSONObject().put("role", "assistant").put("content", it))
                }.onFailure {
                    wait.text = "⚠️ Gagal: ${it.message}\nPeriksa koneksi internet."
                    history.remove(history.length() - 1)
                }
                scrollDown()
            }
        }
    }

    private fun changeMode(m: String, label: String, greet: String) {
        mode = m
        while (history.length() > 0) history.remove(0)
        modeChip?.text = "Mode: $label"
        addMsg(greet, false)
        curTab = 0
        show(chatPage!!)
        refreshTabs()
        scrollDown()
    }

    // ================= scan foto =================
    private fun scan() {
        curTab = 0
        show(chatPage!!)
        refreshTabs()
        ScanBridge.callback = { b64, thumb -> ui.post { onScan(b64, thumb) } }
        minimize()
        startActivity(Intent(this, PickActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun onScan(b64: String?, thumb: Bitmap?) {
        restore()
        if (b64 == null || busy) return
        val typed = input?.text?.toString()?.trim().orEmpty()
        val prompt = typed.ifEmpty { "Baca foto ini. Jika berisi soal, jawab dengan langkah-langkah yang mudah dipahami. Jika bukan soal, jelaskan isi foto." }
        input?.setText("")
        shrinkRobot()
        val iv = ImageView(this).apply {
            setImageBitmap(thumb)
            scaleType = ImageView.ScaleType.CENTER_CROP
            Glass.round(this, dp(14))
        }
        chatBox!!.addView(iv, lp(dpi(140), dpi(100), 0f, 0, dpi(3), 0, dpi(3)).apply { gravity = Gravity.END })
        if (typed.isNotEmpty()) addMsg(typed, true) else addMsg("📷 Scan foto", true)
        val wait = addMsg("⏳ Membaca foto…", false)
        busy = true
        val parts = JSONArray()
            .put(JSONObject().put("type", "text").put("text", prompt))
            .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$b64")))
        val msgs = JSONArray()
            .put(JSONObject().put("role", "system").put("content", sysPrompt()))
            .put(JSONObject().put("role", "user").put("content", parts))
        thread {
            val res = try { Result.success(GroqClient.chat(msgs, Config.VISION_MODELS)) } catch (e: Exception) { Result.failure(e) }
            ui.post {
                busy = false
                res.onSuccess {
                    wait.text = it
                    history.put(JSONObject().put("role", "user").put("content", "[Foto] $prompt"))
                    history.put(JSONObject().put("role", "assistant").put("content", it))
                }.onFailure { wait.text = "⚠️ Gagal membaca foto: ${it.message}" }
                scrollDown()
            }
        }
    }

    // ================= menu =================
    private fun pageBox() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dpi(4), dpi(4), dpi(4), dpi(4)) }

    private fun scroll(v: View) = ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(v) }

    private fun backBar(title: String): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val back = Glass.button(this, "‹ Menu", null, 12f).apply {
            setPadding(dpi(12), dpi(6), dpi(12), dpi(6))
            setOnClickListener { curTab = 1; show(menuPage()); refreshTabs() }
        }
        row.addView(back)
        row.addView(tv(title, 14f, Color.WHITE, true), lp(WC, WC, 0f, dpi(10), 0, 0, 0))
        row.layoutParams = lp(MP, WC, 0f, 0, 0, 0, dpi(10))
        return row
    }

    private fun menuPage(): View {
        val items = listOf(
            Triple("📷", "Scan Foto", "scan"),
            Triple("💬", "Tanya Bebas", "chat"),
            Triple("💻", "Tanyakan Coding (Beta)", "coding"),
            Triple("🎓", "Belajar Coding (Beta)", "belajar"),
            Triple("✖️", "Perkalian Lengkap", "mul"),
            Triple("➗", "Pembagian Lengkap", "div"),
            Triple("🧠", "TES IQ", "iq"),
            Triple("⚙️", "Setting", "set")
        )
        val grid = pageBox()
        items.chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEach { (ic, name, key) ->
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    setPadding(dpi(8), dpi(12), dpi(8), dpi(8))
                    background = Glass.bg(this@FloatingService, 20f)
                    isClickable = true
                    setOnClickListener { openFeature(key) }
                    Glass.pressFx(this)
                }
                card.addView(tv(ic, 26f))
                card.addView(tv(name, 12.5f, Color.WHITE, true).apply { gravity = Gravity.CENTER })
                card.addView(tv(Config.FOOTER, 9f, 0x99FFFFFF.toInt()), lp(WC, WC, 0f, 0, dpi(6), 0, 0))
                row.addView(card, lp(0, dpi(100), 1f, dpi(4), dpi(4), dpi(4), dpi(4)))
            }
            grid.addView(row, lp(MP, WC))
        }
        return scroll(grid)
    }

    private fun openFeature(key: String) {
        when (key) {
            "scan" -> scan()
            "chat" -> changeMode("umum", "Tanya Bebas", "Mode Tanya Bebas aktif. Mau tanya apa? 😊")
            "coding" -> changeMode("coding", "Tanyakan Coding (Beta)", "💻 Mode Tanyakan Coding (Beta). Kirim pertanyaan atau error kodemu!")
            "belajar" -> changeMode("belajar", "Belajar Coding (Beta)", "🎓 Mode Belajar Coding (Beta). Mau belajar bahasa apa? (Python, HTML, Java, dll)")
            "mul" -> show(mathPage(true))
            "div" -> show(mathPage(false))
            "iq" -> show(iqPage())
            "set" -> { curTab = 3; show(settingsPage()); refreshTabs() }
        }
    }

    // ================= perkalian / pembagian =================
    private fun mathPage(mul: Boolean): View {
        val box = pageBox()
        box.addView(backBar(if (mul) "✖️ Perkalian Lengkap" else "➗ Pembagian Lengkap"))
        val a = field("Angka pertama", true)
        val b = field(if (mul) "Angka kedua" else "Pembagi", true)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(a, lp(0, WC, 1f, 0, 0, dpi(4), 0))
        row.addView(tv(if (mul) "×" else "÷", 20f, Color.WHITE, true))
        row.addView(b, lp(0, WC, 1f, dpi(4), 0, 0, 0))
        box.addView(row, lp(MP, WC, 0f, 0, 0, 0, dpi(10)))

        val out = tv("", 12f).apply {
            typeface = Typeface.MONOSPACE
            setPadding(dpi(12), dpi(10), dpi(12), dpi(10))
            background = Glass.bg(this@FloatingService, 14f)
            visibility = View.GONE
        }
        fun showOut(s: String) {
            out.text = s
            out.visibility = View.VISIBLE
            hideIme()
        }
        val go = Glass.button(this, "Hitung", accent, 14f).apply {
            setOnClickListener {
                val x = a.text.toString().toLongOrNull()
                val y = b.text.toString().toLongOrNull()
                if (x == null || y == null) showOut("Isi kedua angka dulu ya 🙂")
                else showOut(if (mul) MathHelper.multiply(x, y) else MathHelper.divide(x, y))
            }
        }
        val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btns.addView(go, lp(0, WC, 1f, 0, 0, dpi(4), 0))
        if (mul) {
            val tbl = Glass.button(this, "Tabel × 1–12", null, 14f).apply {
                setOnClickListener {
                    val x = a.text.toString().toLongOrNull()
                    if (x == null) showOut("Isi angka pertama dulu ya 🙂") else showOut(MathHelper.table(x))
                }
            }
            btns.addView(tbl, lp(0, WC, 1f, dpi(4), 0, 0, 0))
        }
        box.addView(btns, lp(MP, WC, 0f, 0, 0, 0, dpi(10)))
        val hs = HorizontalScrollView(this).apply { addView(out) }
        box.addView(hs, lp(MP, WC))
        return scroll(box)
    }

    // ================= TES IQ =================
    private fun iqPage(): View {
        val box = pageBox()
        box.addView(backBar("🧠 TES IQ"))
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(body)
        var idx = 0
        var score = 0
        val total = IqData.questions.size
        fun render() {
            body.removeAllViews()
            if (idx >= total) {
                val iq = 70 + score * 6
                body.addView(tv("Hasil TES IQ", 16f, Color.WHITE, true))
                body.addView(tv("Benar: $score / $total\nPerkiraan IQ: $iq\n${IqData.label(iq)}", 14f), lp(WC, WC, 0f, 0, dpi(8), 0, dpi(8)))
                body.addView(tv("*Hanya untuk hiburan & latihan, bukan tes IQ resmi.", 10f, 0xAAFFFFFF.toInt()))
                val again = Glass.button(this, "Ulangi Tes", accent, 14f).apply {
                    setOnClickListener { idx = 0; score = 0; render() }
                }
                body.addView(again, lp(MP, WC, 0f, 0, dpi(12), 0, 0))
                return
            }
            val q = IqData.questions[idx]
            body.addView(tv("Soal ${idx + 1} dari $total", 11f, 0xB3FFFFFF.toInt()))
            body.addView(tv(q.q, 15f, Color.WHITE, true), lp(WC, WC, 0f, 0, dpi(6), 0, dpi(10)))
            q.opts.forEachIndexed { i, o ->
                val ob = Glass.button(this, o, null, 14f).apply {
                    setOnClickListener {
                        if (i == q.ans) score++
                        idx++
                        render()
                    }
                }
                body.addView(ob, lp(MP, WC, 0f, 0, dpi(4), 0, dpi(4)))
            }
        }
        render()
        return scroll(box)
    }

    // ================= setting =================
    private fun settingsPage(): View {
        val box = pageBox()
        box.addView(tv("⚙ Setting", 15f, Color.WHITE, true), lp(WC, WC, 0f, 0, 0, 0, dpi(10)))
        box.addView(tv("Warna", 12f, 0xCCFFFFFF.toInt()))
        val colors = intArrayOf(
            0xFF30D158.toInt(), 0xFF0A84FF.toInt(), 0xFFBF5AF2.toInt(),
            0xFFFF9F0A.toInt(), 0xFFFF375F.toInt(), 0xFF64D2FF.toInt()
        )
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        colors.forEach { col ->
            val dot = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(col)
                    setStroke(dpi(if (col == accent) 3 else 1), if (col == accent) Color.WHITE else 0x66FFFFFF)
                }
                setOnClickListener {
                    Prefs.setAccent(this@FloatingService, col)
                    applyAccent()
                    show(settingsPage())
                }
            }
            row.addView(dot, lp(dpi(34), dpi(34), 0f, 0, dpi(8), dpi(10), dpi(14)))
        }
        box.addView(row)

        val lbl = tv("Opacity panel: ${Prefs.opacity(this)}%", 12f, 0xCCFFFFFF.toInt())
        box.addView(lbl)
        val sb = SeekBar(this).apply {
            max = 80
            progress = Prefs.opacity(this@FloatingService) - 20
            progressTintList = ColorStateList.valueOf(accent)
            thumbTintList = ColorStateList.valueOf(accent)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    Prefs.setOpacity(this@FloatingService, p + 20)
                    lbl.text = "Opacity panel: ${p + 20}%"
                    styleRoot()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        box.addView(sb, lp(MP, WC, 0f, 0, dpi(6), 0, dpi(14)))
        val reset = Glass.button(this, "Reset", null, 13f).apply {
            setOnClickListener {
                Prefs.setAccent(this@FloatingService, 0xFF30D158.toInt())
                Prefs.setOpacity(this@FloatingService, 80)
                styleRoot()
                applyAccent()
                show(settingsPage())
            }
        }
        box.addView(reset, lp(MP, WC))
        return scroll(box)
    }

    private fun applyAccent() {
        robot?.accent = accent
        sendBtn?.background = Glass.accentBg(this, accent, 40f)
        refreshTabs()
    }
}
