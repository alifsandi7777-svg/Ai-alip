package com.alip.ai

object MathHelper {
    fun multiply(a: Long, b: Long): String {
        val bs = b.toString()
        val res = a * b
        val w = maxOf(res.toString().length, a.toString().length, bs.length + 1) + 2
        val sb = StringBuilder()
        sb.appendLine("$a × $b")
        sb.appendLine()
        sb.appendLine(a.toString().padStart(w))
        sb.appendLine("×" + bs.padStart(w - 1))
        sb.appendLine("-".repeat(w))
        if (bs.length > 1) {
            var mult = 1L
            for (ch in bs.reversed()) {
                val d = ch - '0'
                sb.appendLine((a * d * mult).toString().padStart(w) + "   ← $a × ${d * mult}")
                mult *= 10
            }
            sb.appendLine("-".repeat(w))
        }
        sb.appendLine(res.toString().padStart(w))
        sb.appendLine()
        sb.append("Hasil: $a × $b = $res")
        return sb.toString()
    }

    fun table(n: Long): String {
        val sb = StringBuilder("Tabel perkalian $n\n\n")
        for (i in 1..12) sb.appendLine("$n × ${i.toString().padStart(2)} = ${n * i}")
        return sb.toString().trimEnd()
    }

    fun divide(a: Long, b: Long): String {
        if (b == 0L) return "Tidak bisa dibagi dengan nol."
        val sb = StringBuilder("$a ÷ $b\n\nLangkah pembagian bersusun:\n")
        var rem = 0L
        val q = StringBuilder()
        for ((i, ch) in a.toString().withIndex()) {
            rem = rem * 10 + (ch - '0')
            val d = rem / b
            val used = d * b
            sb.appendLine("${i + 1}. Turunkan $ch → $rem ÷ $b = $d ($d × $b = $used), sisa ${rem - used}")
            rem -= used
            q.append(d)
        }
        val quotient = q.toString().trimStart('0').ifEmpty { "0" }
        sb.appendLine()
        sb.appendLine("Hasil bagi = $quotient")
        sb.appendLine("Sisa       = $rem")
        if (rem != 0L) {
            var r = rem
            val dec = StringBuilder()
            repeat(4) {
                r *= 10
                dec.append(r / b)
                r %= b
            }
            sb.appendLine("Desimal    ≈ $quotient,$dec")
        }
        sb.append("Cek: $quotient × $b + $rem = ${quotient.toLong() * b + rem}")
        return sb.toString()
    }
}
