package com.alip.ai

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object GroqClient {
    fun chat(messages: JSONArray, models: List<String>): String {
        var err = "Tidak ada respons"
        for (m in models) {
            try {
                return call(m, messages)
            } catch (e: Exception) {
                err = e.message ?: "Error"
            }
        }
        throw Exception(err)
    }

    private fun call(model: String, messages: JSONArray): String {
        val body = JSONObject()
            .put("model", model)
            .put("messages", messages)
            .put("temperature", 0.6)
            .put("max_tokens", 4096)
        val c = URL(Config.ENDPOINT).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 20000
        c.readTimeout = 90000
        c.doOutput = true
        c.setRequestProperty("Authorization", "Bearer ${Config.API_KEY}")
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val txt = stream.bufferedReader().use { it.readText() }
        if (code !in 200..299) throw Exception("HTTP $code: " + txt.take(160))
        var out = JSONObject(txt).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").optString("content", "")
        out = out.replace(Regex("(?s)<think>.*?</think>"), "").trim()
        if (out.isEmpty()) throw Exception("Jawaban kosong")
        return out
    }
}
