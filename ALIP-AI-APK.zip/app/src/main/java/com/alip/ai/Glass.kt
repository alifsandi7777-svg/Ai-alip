package com.alip.ai

import android.content.Context
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.TextView

fun Context.dp(v: Number): Float = v.toFloat() * resources.displayMetrics.density
fun Context.dpi(v: Number): Int = dp(v).toInt()

object Glass {
    fun withAlpha(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a shl 24)

    /** Kaca ala iPhone: gradasi putih transparan + garis tepi tipis */
    fun bg(
        ctx: Context, radius: Float = 20f,
        top: Int = 0x55FFFFFF, bottom: Int = 0x1FFFFFFF, stroke: Int = 0x66FFFFFF
    ): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)).apply {
            cornerRadius = ctx.dp(radius)
            setStroke(ctx.dpi(1), stroke)
        }

    fun accentBg(ctx: Context, accent: Int, radius: Float = 20f): GradientDrawable =
        GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(withAlpha(accent, 0xF0), withAlpha(accent, 0xA0))
        ).apply {
            cornerRadius = ctx.dp(radius)
            setStroke(ctx.dpi(1), 0x99FFFFFF.toInt())
        }

    fun circle(v: View) {
        v.clipToOutline = true
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setOval(0, 0, view.width, view.height)
            }
        }
    }

    fun round(v: View, px: Float) {
        v.clipToOutline = true
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, px)
            }
        }
    }

    fun text(ctx: Context, t: String, sp: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView =
        TextView(ctx).apply {
            text = t
            textSize = sp
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    fun pressFx(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> view.animate().scaleX(0.95f).scaleY(0.95f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }
            false
        }
    }

    fun button(ctx: Context, label: String, accent: Int? = null, sp: Float = 15f): TextView {
        val b = text(ctx, label, sp, Color.WHITE, true)
        b.gravity = Gravity.CENTER
        b.setPadding(ctx.dpi(22), ctx.dpi(12), ctx.dpi(22), ctx.dpi(12))
        b.background = if (accent != null) accentBg(ctx, accent, 26f) else bg(ctx, 26f)
        b.isClickable = true
        pressFx(b)
        return b
    }
}
