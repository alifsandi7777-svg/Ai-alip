package com.alip.ai

object Config {
    // API key Groq
    const val API_KEY = "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"
    const val ENDPOINT = "https://api.groq.com/openai/v1/chat/completions"

    // Model dicoba berurutan (otomatis pindah jika ada yang tidak tersedia)
    val TEXT_MODELS = listOf("openai/gpt-oss-120b", "qwen/qwen3.6-27b", "llama-3.3-70b-versatile")
    val VISION_MODELS = listOf("qwen/qwen3.6-27b", "qwen/qwen3.8-27b")

    const val PASSWORD = "ALIPAI2026"
    const val FOOTER = "@ALIP_🙌"
}
