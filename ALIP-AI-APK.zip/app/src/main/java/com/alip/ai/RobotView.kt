package com.alip.ai

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Robot 3D (gradasi + kedalaman) dengan logo Claude & Gemini yang mengorbit. */
class RobotView(ctx: Context) : View(ctx) {
    var accent: Int = 0xFF30D158.toInt()
    private var t = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    private val PI = Math.PI.toFloat()

    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 6000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    private fun logo(c: Canvas, k: Int, x: Float, y: Float, r: Float, a: Int) {
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = Color.argb(a, 255, 255, 255)
        c.drawCircle(x, y, r * 1.4f, p)
        if (k == 0) { // Claude (bintang oranye)
            p.style = Paint.Style.STROKE
            p.strokeCap = Paint.Cap.ROUND
            p.strokeWidth = r * 0.2f
            p.color = Color.argb(a, 0xD9, 0x77, 0x57)
            for (i in 0 until 12) {
                val an = i * (PI / 6f) + 0.2f
                val len = r * (0.62f + 0.38f * (((i * 5) % 4) / 3f))
                c.drawLine(x + cos(an) * r * 0.18f, y + sin(an) * r * 0.18f, x + cos(an) * len, y + sin(an) * len, p)
            }
            p.strokeCap = Paint.Cap.BUTT
        } else { // Gemini (bintang 4 titik gradasi)
            path.reset()
            path.moveTo(x, y - r)
            path.quadTo(x, y, x + r, y)
            path.quadTo(x, y, x, y + r)
            path.quadTo(x, y, x - r, y)
            path.quadTo(x, y, x, y - r)
            path.close()
            p.style = Paint.Style.FILL
            p.shader = LinearGradient(
                x - r, y - r, x + r, y + r,
                intArrayOf(0xFF4285F4.toInt(), 0xFF9B72CB.toInt(), 0xFFD96570.toInt()), null, Shader.TileMode.CLAMP
            )
            p.alpha = a
            c.drawPath(path, p)
            p.shader = null
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val s = h
        val cx = w / 2f
        val cy = h / 2f
        val ang = t * 2f * PI
        val bob = sin(ang * 2f) * 0.02f * s
        val orbR = min(w * 0.42f, s * 0.75f)

        // logo di belakang robot
        for (k in 0..1) {
            val a = ang + k * PI
            val z = sin(a)
            if (z < 0f) {
                val sc = 0.8f + 0.25f * z
                logo(c, k, cx + cos(a) * orbR, cy - 0.05f * s + z * 0.1f * s, 0.1f * s * sc, (200 + 55 * z).toInt())
            }
        }

        // bayangan
        c.save()
        c.scale(1f, 0.22f, cx, cy + 0.43f * s)
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy + 0.43f * s, 0.22f * s, 0x66000000, 0x00000000, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy + 0.43f * s, 0.22f * s * (1f - bob / s), p)
        c.restore()
        p.shader = null

        val hy = cy - 0.08f * s + bob
        val tt = hy + 0.15f * s

        // lengan (di belakang badan)
        val sw = sin(ang * 2f) * 0.03f * s
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 0.055f * s
        p.color = 0xFFC9D2DF.toInt()
        c.drawLine(cx - 0.17f * s, tt + 0.05f * s, cx - 0.25f * s, tt + 0.2f * s + sw, p)
        c.drawLine(cx + 0.17f * s, tt + 0.05f * s, cx + 0.27f * s, tt - 0.01f * s - sw * 2f, p)
        p.strokeCap = Paint.Cap.BUTT
        p.style = Paint.Style.FILL

        // badan
        rect.set(cx - 0.15f * s, tt, cx + 0.15f * s, tt + 0.25f * s)
        p.shader = LinearGradient(rect.left, rect.top, rect.right, rect.bottom, 0xFFFFFFFF.toInt(), 0xFF9AA7BA.toInt(), Shader.TileMode.CLAMP)
        c.drawRoundRect(rect, 0.09f * s, 0.09f * s, p)
        p.shader = RadialGradient(cx, tt + 0.11f * s, 0.07f * s, accent, Glass.withAlpha(accent, 0), Shader.TileMode.CLAMP)
        c.drawCircle(cx, tt + 0.11f * s, 0.07f * s, p)
        p.shader = null
        p.color = accent
        c.drawCircle(cx, tt + 0.11f * s, 0.025f * s, p)

        // kepala (sedikit miring)
        c.save()
        c.rotate(sin(ang * 2f) * 3f, cx, hy + 0.2f * s)

        // antena
        p.style = Paint.Style.STROKE
        p.strokeWidth = 0.014f * s
        p.color = 0xFF9AA7BA.toInt()
        c.drawLine(cx, hy - 0.17f * s, cx, hy - 0.26f * s, p)
        p.style = Paint.Style.FILL
        val pulse = 0.028f * s * (1f + 0.25f * sin(ang * 4f))
        p.shader = RadialGradient(cx, hy - 0.27f * s, pulse * 2.2f, accent, Glass.withAlpha(accent, 0), Shader.TileMode.CLAMP)
        c.drawCircle(cx, hy - 0.27f * s, pulse * 2.2f, p)
        p.shader = null
        p.color = Color.WHITE
        c.drawCircle(cx, hy - 0.27f * s, pulse * 0.7f, p)

        val hl = cx - 0.27f * s
        val hr = cx + 0.27f * s
        val ht = hy - 0.17f * s
        val hb = hy + 0.17f * s
        // ketebalan (efek 3D)
        rect.set(hl + 0.016f * s, ht + 0.022f * s, hr + 0.016f * s, hb + 0.022f * s)
        p.color = 0xFF7D8AA0.toInt()
        c.drawRoundRect(rect, 0.11f * s, 0.11f * s, p)
        // telinga
        p.color = 0xFFB8C2D2.toInt()
        c.drawCircle(hl - 0.005f * s, hy, 0.045f * s, p)
        c.drawCircle(hr + 0.005f * s, hy, 0.045f * s, p)
        p.color = accent
        c.drawCircle(hl - 0.005f * s, hy, 0.02f * s, p)
        c.drawCircle(hr + 0.005f * s, hy, 0.02f * s, p)
        // permukaan kepala
        rect.set(hl, ht, hr, hb)
        p.shader = LinearGradient(
            hl, ht, hr, hb,
            intArrayOf(0xFFFFFFFF.toInt(), 0xFFE3E8F0.toInt(), 0xFFA9B4C6.toInt()), null, Shader.TileMode.CLAMP
        )
        c.drawRoundRect(rect, 0.11f * s, 0.11f * s, p)
        // layar wajah
        rect.set(hl + 0.045f * s, ht + 0.045f * s, hr - 0.045f * s, hb - 0.045f * s)
        p.shader = LinearGradient(0f, rect.top, 0f, rect.bottom, 0xFF16223A.toInt(), 0xFF04070D.toInt(), Shader.TileMode.CLAMP)
        c.drawRoundRect(rect, 0.08f * s, 0.08f * s, p)
        p.shader = null

        // mata (ikut menoleh + berkedip)
        val tx = sin(ang) * 0.02f * s
        val blink = if ((t * 3f) % 1f > 0.93f) 0.12f else 1f
        for (sign in intArrayOf(-1, 1)) {
            val ex = cx + tx + sign * 0.09f * s
            val ey = hy - 0.01f * s
            p.shader = RadialGradient(ex, ey, 0.09f * s, Glass.withAlpha(accent, 110), Glass.withAlpha(accent, 0), Shader.TileMode.CLAMP)
            c.drawCircle(ex, ey, 0.09f * s, p)
            p.shader = null
            p.color = accent
            rect.set(ex - 0.04f * s, ey - 0.05f * s * blink, ex + 0.04f * s, ey + 0.05f * s * blink)
            c.drawOval(rect, p)
            p.color = Color.WHITE
            c.drawCircle(ex - 0.012f * s, ey - 0.018f * s * blink, 0.011f * s, p)
        }
        // senyum
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 0.014f * s
        p.color = accent
        rect.set(cx + tx - 0.05f * s, hy + 0.02f * s, cx + tx + 0.05f * s, hy + 0.09f * s)
        c.drawArc(rect, 20f, 140f, false, p)
        p.strokeCap = Paint.Cap.BUTT
        p.style = Paint.Style.FILL
        // kilau kaca
        p.color = Color.argb(150, 255, 255, 255)
        rect.set(hl + 0.03f * s, ht + 0.018f * s, hl + 0.16f * s, ht + 0.03f * s)
        c.drawRoundRect(rect, 0.01f * s, 0.01f * s, p)
        c.restore()

        // logo di depan robot
        for (k in 0..1) {
            val a = ang + k * PI
            val z = sin(a)
            if (z >= 0f) {
                val sc = 0.8f + 0.25f * z
                logo(c, k, cx + cos(a) * orbR, cy - 0.05f * s + z * 0.1f * s, 0.1f * s * sc, (200 + 55 * z).toInt())
            }
        }
    }
}
