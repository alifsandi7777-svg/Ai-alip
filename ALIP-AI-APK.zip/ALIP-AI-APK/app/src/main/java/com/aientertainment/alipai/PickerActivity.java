package com.aientertainment.alipai;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;

public class PickerActivity extends Activity {
    static ValueCallback<Uri[]> cb;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Intent in = (Intent) getIntent().getParcelableExtra("intent");
        try { startActivityForResult(in, 1); } catch (Exception e) { done(null); }
    }

    @Override protected void onActivityResult(int r, int res, Intent d) {
        done(WebChromeClient.FileChooserParams.parseResult(res, d));
    }

    private void done(Uri[] u) {
        if (cb != null) { cb.onReceiveValue(u); cb = null; }
        finish();
    }
}
