package com.aientertainment.alipai;

import android.animation.ValueAnimator;
import android.app.*;
import android.content.Intent;
import android.content.Context;
import android.content.pm.ServiceInfo;
import android.graphics.*;
import android.net.Uri;
import android.os.*;
import android.util.DisplayMetrics;
import android.view.*;
import android.webkit.*;
import android.widget.LinearLayout;

public class OverlayService extends Service {
    private WindowManager wm;
    private LinearLayout root;
    private WebView web;
    private WindowManager.LayoutParams lp;
    private boolean open = false;
    private float d;
    private Robot robot;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent i, int f, int id) {
        if (root == null) { startFg(); build(); }
        return START_STICKY;
    }

    private void startFg() {
        String ch = "alip";
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(new NotificationChannel(ch, "ALIP AI", NotificationManager.IMPORTANCE_LOW));
        Notification.Builder nb = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, ch) : new Notification.Builder(this);
        Notification n = nb.setContentTitle("ALIP AI aktif").setContentText("Robot mengambang sedang berjalan")
                .setSmallIcon(R.mipmap.ic_launcher).build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1, n);
    }

    private void build() {
        d = getResources().getDisplayMetrics().density;
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        robot = new Robot(this);
        root.addView(robot, new LinearLayout.LayoutParams((int) (96 * d), (int) (96 * d)));

        web = new WebView(this);
        web.setBackgroundColor(Color.TRANSPARENT);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        web.addJavascriptInterface(new PanelBridge(), "Android");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                PickerActivity.cb = cb;
                Intent i = new Intent(OverlayService.this, PickerActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.putExtra("intent", p.createIntent());
                startActivity(i);
                return true;
            }
        });
        web.loadUrl("file:///android_asset/index.html?panel=1");
        web.setVisibility(View.GONE);
        root.addView(web, new LinearLayout.LayoutParams((int) (300 * d), (int) (420 * d)));

        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        lp = new WindowManager.LayoutParams(-2, -2, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = (int) (16 * d);
        lp.y = (int) (160 * d);
        wm.addView(root, lp);
    }

    private void toggle() {
        open = !open;
        web.setVisibility(open ? View.VISIBLE : View.GONE);
        if (open) {
            lp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            DisplayMetrics m = getResources().getDisplayMetrics();
            lp.x = Math.max(0, Math.min(lp.x, m.widthPixels - (int) (300 * d)));
            lp.y = Math.max(0, Math.min(lp.y, m.heightPixels - (int) (530 * d)));
        } else {
            lp.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        }
        wm.updateViewLayout(root, lp);
    }

    class PanelBridge {
        @JavascriptInterface public void closePanel() { root.post(new Runnable() { public void run() { if (open) toggle(); } }); }
        @JavascriptInterface public void setRobotAlpha(final int pct) { root.post(new Runnable() { public void run() { robot.setAlpha(pct / 100f); } }); }
        @JavascriptInterface public void stop() { root.post(new Runnable() { public void run() { stopSelf(); } }); }
    }

    @Override public void onDestroy() {
        if (root != null) { try { wm.removeView(root); } catch (Exception e) {} web.destroy(); root = null; }
        super.onDestroy();
    }

    /** Robot cyborg mata biru + 4 logo AI (Claude, ChatGPT, Gemini, Dola) yang mengorbit. */
    class Robot extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Shader headG = new LinearGradient(32, 32, 68, 66, 0xFFF1F5FC, 0xFF7F8CA3, Shader.TileMode.CLAMP);
        private final int[] ec = {0xFFE6F6FF, 0xFF2FA8FF, 0x002FA8FF};
        private final float[] es = {0f, .45f, 1f};
        private final Shader eyeL = new RadialGradient(44, 49, 7, ec, es, Shader.TileMode.CLAMP);
        private final Shader eyeR = new RadialGradient(56, 49, 7, ec, es, Shader.TileMode.CLAMP);
        private final Shader gemG = new LinearGradient(-6, -6, 6, 6, 0xFF3B8CFF, 0xFFC18BFF, Shader.TileMode.CLAMP);
        private final Shader dolaG = new LinearGradient(-5, -5, 5, 5, 0xFFFF7AA8, 0xFF7B5CFF, Shader.TileMode.CLAMP);
        private float ang = 0;
        private ValueAnimator an;
        private float sx, sy; private int ox, oy; private boolean mv;

        Robot(Context c) { super(c); }

        @Override protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            an = ValueAnimator.ofFloat(0, 360);
            an.setDuration(9000);
            an.setRepeatCount(ValueAnimator.INFINITE);
            an.setInterpolator(new android.view.animation.LinearInterpolator());
            an.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                public void onAnimationUpdate(ValueAnimator a) { ang = (Float) a.getAnimatedValue(); invalidate(); }
            });
            an.start();
        }

        @Override protected void onDetachedFromWindow() { if (an != null) an.cancel(); super.onDetachedFromWindow(); }

        private void icon(Canvas c, int k) {
            p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(0x33FFFFFF); c.drawCircle(0, 0, 8.5f, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(0.6f); p.setColor(0x99FFFFFF); c.drawCircle(0, 0, 8.5f, p);
            p.setStrokeCap(Paint.Cap.ROUND);
            if (k == 0) {
                p.setStrokeWidth(1.4f); p.setColor(0xFFE07A50);
                c.drawLine(0, -5, 0, 5, p); c.drawLine(-5, 0, 5, 0, p);
                c.drawLine(-3.5f, -3.5f, 3.5f, 3.5f, p); c.drawLine(3.5f, -3.5f, -3.5f, 3.5f, p);
            } else if (k == 1) {
                p.setStrokeWidth(1.2f); p.setColor(0xFFE6FFF7);
                Path h = new Path();
                for (int i = 0; i < 6; i++) {
                    double t = Math.toRadians(-90 + 60 * i);
                    float x = (float) Math.cos(t) * 5.5f, y = (float) Math.sin(t) * 5.5f;
                    if (i == 0) h.moveTo(x, y); else h.lineTo(x, y);
                }
                h.close(); c.drawPath(h, p);
                p.setStrokeWidth(1f);
                c.drawLine(0, 0, 0, -5.5f, p); c.drawLine(0, 0, 4.76f, 2.75f, p); c.drawLine(0, 0, -4.76f, 2.75f, p);
            } else if (k == 2) {
                p.setStyle(Paint.Style.FILL); p.setShader(gemG);
                Path g = new Path(); g.moveTo(0, -6); g.quadTo(0, 0, 6, 0); g.quadTo(0, 0, 0, 6); g.quadTo(0, 0, -6, 0); g.quadTo(0, 0, 0, -6); g.close();
                c.drawPath(g, p); p.setShader(null);
            } else {
                p.setStyle(Paint.Style.FILL); p.setShader(dolaG); c.drawRoundRect(new RectF(-5, -5, 5, 5), 3, 3, p); p.setShader(null);
                p.setColor(Color.WHITE); p.setTextSize(8); p.setTextAlign(Paint.Align.CENTER); p.setFakeBoldText(true);
                c.drawText("D", 0, 3, p); p.setFakeBoldText(false);
            }
            p.setStrokeCap(Paint.Cap.BUTT);
        }

        @Override protected void onDraw(Canvas c) {
            c.scale(d * 0.96f, d * 0.96f);
            float pulse = 0.75f + 0.25f * (float) Math.sin(Math.toRadians(ang * 8));
            p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(0x59091428); c.drawCircle(50, 50, 47, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(0.8f); p.setColor(0x26FFFFFF); c.drawCircle(50, 50, 38, p);
            p.setColor(0xFF9FB3D6); p.setStrokeWidth(1.6f); c.drawLine(50, 32, 50, 22, p);
            p.setStyle(Paint.Style.FILL); p.setColor(0xFF3BA4FF); c.drawCircle(50, 21, 2.4f, p);
            p.setColor(0xFF25324A);
            c.drawRoundRect(new RectF(28, 44, 33, 56), 2, 2, p); c.drawRoundRect(new RectF(67, 44, 72, 56), 2, 2, p);
            c.drawRoundRect(new RectF(42, 66, 58, 72), 2, 2, p);
            p.setColor(0xFF38BDF8); c.drawCircle(30.5f, 50, 1, p); c.drawCircle(69.5f, 50, 1, p);
            p.setShader(headG); c.drawRoundRect(new RectF(32, 32, 68, 66), 12, 12, p); p.setShader(null);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(0.8f); p.setColor(0xFFCFD9EA);
            c.drawRoundRect(new RectF(32, 32, 68, 66), 12, 12, p);
            p.setStyle(Paint.Style.FILL); p.setColor(0x59142040); c.drawRoundRect(new RectF(55, 36, 67, 62), 5, 5, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(0.8f); p.setColor(0xFF38BDF8);
            c.drawLine(56, 36, 56, 41, p); c.drawLine(56, 41, 63, 41, p); c.drawLine(64, 59, 64, 63, p); c.drawLine(58, 63, 64, 63, p);
            p.setStyle(Paint.Style.FILL); p.setColor(0xFF070D1C); c.drawRoundRect(new RectF(36, 42, 64, 56), 7, 7, p);
            p.setShader(eyeL); p.setAlpha((int) (255 * pulse)); c.drawCircle(44, 49, 7, p);
            p.setShader(eyeR); p.setAlpha((int) (255 * pulse)); c.drawCircle(56, 49, 7, p);
            p.setShader(null); p.setAlpha(255); p.setColor(0xFFBFE6FF); c.drawCircle(44, 49, 1.8f, p); c.drawCircle(56, 49, 1.8f, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(0.8f); p.setColor(0xFF2B3A58);
            c.drawLine(43, 60, 57, 60, p); c.drawLine(45, 62, 55, 62, p);
            for (int k = 0; k < 4; k++) {
                double a = Math.toRadians(ang + 90 * k);
                c.save(); c.translate((float) (50 + Math.sin(a) * 38), (float) (50 - Math.cos(a) * 38)); icon(c, k); c.restore();
            }
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    sx = e.getRawX(); sy = e.getRawY(); ox = lp.x; oy = lp.y; mv = false; return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = e.getRawX() - sx, dy = e.getRawY() - sy;
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) mv = true;
                    if (mv) { lp.x = Math.max(0, ox + (int) dx); lp.y = Math.max(0, oy + (int) dy); wm.updateViewLayout(root, lp); }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!mv) toggle();
                    return true;
            }
            return true;
        }
    }
}
