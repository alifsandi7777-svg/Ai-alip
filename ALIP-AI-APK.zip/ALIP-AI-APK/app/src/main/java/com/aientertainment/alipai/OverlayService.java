package com.aientertainment.alipai;

import android.animation.ValueAnimator;
import android.app.*;
import android.content.Intent;
import android.content.Context;
import android.content.pm.ServiceInfo;
import android.graphics.*;
import android.net.Uri;
import android.os.*;
import android.util.DisplayMetrics;
import android.view.*;
import android.webkit.*;
import android.widget.LinearLayout;

public class OverlayService extends Service {
    private WindowManager wm;
    private LinearLayout root;
    private WebView web;
    private WindowManager.LayoutParams lp;
    private boolean open = false;
    private float d;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent i, int f, int id) {
        if (root == null) { startFg(); build(); }
        return START_STICKY;
    }

    private void startFg() {
        String ch = "alip";
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(new NotificationChannel(ch, "ALIP AI", NotificationManager.IMPORTANCE_LOW));
        Notification.Builder nb = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, ch) : new Notification.Builder(this);
        Notification n = nb.setContentTitle("ALIP AI aktif").setContentText("Robot mengambang sedang berjalan")
                .setSmallIcon(R.mipmap.ic_launcher).build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1, n);
    }

    private void build() {
        d = getResources().getDisplayMetrics().density;
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.addView(new Robot(this), new LinearLayout.LayoutParams((int) (84 * d), (int) (84 * d)));

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        web.addJavascriptInterface(new PanelBridge(), "Android");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                PickerActivity.cb = cb;
                Intent i = new Intent(OverlayService.this, PickerActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.putExtra("intent", p.createIntent());
                startActivity(i);
                return true;
            }
        });
        web.loadUrl("file:///android_asset/index.html?panel=1");
        web.setVisibility(View.GONE);
        root.addView(web, new LinearLayout.LayoutParams((int) (280 * d), (int) (380 * d)));

        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        lp = new WindowManager.LayoutParams(-2, -2, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = (int) (16 * d);
        lp.y = (int) (160 * d);
        wm.addView(root, lp);
    }

    private void toggle() {
        open = !open;
        web.setVisibility(open ? View.VISIBLE : View.GONE);
        if (open) {
            lp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            DisplayMetrics m = getResources().getDisplayMetrics();
            lp.x = Math.max(0, Math.min(lp.x, m.widthPixels - (int) (280 * d)));
            lp.y = Math.max(0, Math.min(lp.y, m.heightPixels - (int) (470 * d)));
        } else {
            lp.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        }
        wm.updateViewLayout(root, lp);
    }

    class PanelBridge {
        @JavascriptInterface public void closePanel() { root.post(new Runnable() { public void run() { if (open) toggle(); } }); }
        @JavascriptInterface public void stop() { root.post(new Runnable() { public void run() { stopSelf(); } }); }
    }

    @Override public void onDestroy() {
        if (root != null) { try { wm.removeView(root); } catch (Exception e) {} web.destroy(); root = null; }
        super.onDestroy();
    }

    /** Robot kecil + 5 percikan oranye yang berputar. */
    class Robot extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float ang = 0;
        private ValueAnimator an;
        private float sx, sy; private int ox, oy; private boolean mv;

        Robot(Context c) { super(c); }

        @Override protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            an = ValueAnimator.ofFloat(0, 360);
            an.setDuration(9000);
            an.setRepeatCount(ValueAnimator.INFINITE);
            an.setInterpolator(new android.view.animation.LinearInterpolator());
            an.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                public void onAnimationUpdate(ValueAnimator a) { ang = (Float) a.getAnimatedValue(); invalidate(); }
            });
            an.start();
        }

        @Override protected void onDetachedFromWindow() { if (an != null) an.cancel(); super.onDetachedFromWindow(); }

        @Override protected void onDraw(Canvas c) {
            c.scale(d, d);
            p.setStyle(Paint.Style.FILL); p.setColor(0x66103b21);
            c.drawCircle(42, 42, 41, p);
            p.setColor(Color.WHITE);
            c.drawRoundRect(new RectF(24, 30, 60, 60), 10, 10, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(0xFF14633A);
            c.drawRoundRect(new RectF(24, 30, 60, 60), 10, 10, p);
            p.setStyle(Paint.Style.FILL);
            c.drawCircle(34, 43, 4.5f, p); c.drawCircle(50, 43, 4.5f, p);
            c.drawRoundRect(new RectF(30, 61, 54, 70), 4, 4, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.ROUND);
            Path m = new Path(); m.moveTo(34, 51); m.quadTo(42, 57, 50, 51); c.drawPath(m, p);
            p.setColor(Color.WHITE); c.drawLine(42, 30, 42, 23, p);
            p.setStyle(Paint.Style.FILL); p.setColor(0xFFC8232C); c.drawCircle(42, 20, 4, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(0xFFE07A50);
            for (int k = 0; k < 5; k++) {
                double a = Math.toRadians(ang + 72 * k);
                float px = (float) (42 + Math.sin(a) * 36), py = (float) (42 - Math.cos(a) * 36);
                for (int j = 0; j < 4; j++) {
                    double t = Math.toRadians(45 * j);
                    float dx = (float) (Math.cos(t) * 5), dy = (float) (Math.sin(t) * 5);
                    c.drawLine(px - dx, py - dy, px + dx, py + dy, p);
                }
            }
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    sx = e.getRawX(); sy = e.getRawY(); ox = lp.x; oy = lp.y; mv = false; return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = e.getRawX() - sx, dy = e.getRawY() - sy;
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) mv = true;
                    if (mv) { lp.x = Math.max(0, ox + (int) dx); lp.y = Math.max(0, oy + (int) dy); wm.updateViewLayout(root, lp); }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!mv) toggle();
                    return true;
            }
            return true;
        }
    }
}
